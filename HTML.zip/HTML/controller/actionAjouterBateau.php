<?php
session_start();
require_once('../database/bdd.php');
if(isset($_POST["ajouterBateau"])) {
	if(!empty($_POST["immatriculation"]) && !empty($_POST["dateAchat"]) && !empty($_POST["heureUtilisation"]) && !empty($_POST["marque"]) && !empty($_POST["chevaux"]) && !empty($_POST["energie"]) && !empty($_POST["descriptionModele"])) {
		
		
		$stid = oci_parse($conn, 'INSERT INTO modele (LIBELLE_MODELE, MARQUE, CHEVAUX, ENERGIE) VALUES(:myLibelle, :myMarque, :myChevaux, :myEnergie)');



		oci_bind_by_name($stid, ':myLibelle', $_POST["descriptionModele"]);
		oci_bind_by_name($stid, ':myMarque', $_POST["marque"]);
		oci_bind_by_name($stid, ':myChevaux', $_POST["chevaux"]);
		oci_bind_by_name($stid, ':myEnergie', $_POST["energie"]);

		$r = oci_execute($stid);  // exécution et validation

		if ($r) {
			$stid = oci_parse($conn, 'SELECT * FROM modele WHERE libelle_modele =:myLibelle And marque=:myMarque And chevaux=:myChevaux And energie=:myEnergie');
			oci_bind_by_name($stid, ':myLibelle', $_POST["descriptionModele"]);
			oci_bind_by_name($stid, ':myMarque', $_POST["marque"]);
			oci_bind_by_name($stid, ':myChevaux', $_POST["chevaux"]);
			oci_bind_by_name($stid, ':myEnergie', $_POST["energie"]);
	
			$r = oci_execute($stid);  // exécution et validation
			while (($modele = oci_fetch_array($stid, OCI_BOTH)) != false) {
				$idModele = $modele['ID_MODELE'];
			}
		}

		
   
		// Création du timestamp à partir du date donnée
		
		$expl=explode('/',$_POST["dateAchat"]);
		$rev=array_reverse($expl);
		$new_date=implode('-',$expl);
		$date= new datetime($_POST["dateAchat"]);
		$time =$date->format("d-M-Y");
		var_dump ($time);
// jeudi 3 mars
	
		// Créer le nouveau format à partir du timestamp
		$stid = oci_parse($conn, 'INSERT INTO bateau (NOIMMATRICULATION, ID_AGENCE, ID_MODELE, ID_TYPE, DATE_ACHAT,HEURE_UTILISATION) VALUES (:myImma,:myAgence,:myModele,:myType,:myDate,:myHeure)');
		oci_bind_by_name($stid, ':myImma', $_POST["immatriculation"]);
		oci_bind_by_name($stid, ':myAgence', $_SESSION["idAgence"]);
		oci_bind_by_name($stid, ':myModele', $idModele);
		oci_bind_by_name($stid, ':myType', $_POST["typeBateau"]);
		oci_bind_by_name($stid, ':myDate', $time);
		oci_bind_by_name($stid, ':myHeure', $_POST["heureUtilisation"]);

		$r=oci_execute($stid);  // exécution et validation
		
		oci_close($conn);

		Header('Location: ../view/listeBateau.php');
	
	}else {
		Header('Location: ajouterBateau.php');
	}
}else {
	Header('Location: ajouterBateau.php');
}
?>