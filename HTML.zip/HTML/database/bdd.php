<?php
// Create connection to Oracle
$conn = oci_connect("CLABAUTBZ2223", "CLABAUTBZ222301",
"144.21.67.201:1521/PDBEST21.631174089.oraclecloud.internal");
if (!$conn) {
   $m = oci_error();
   echo $m['message'], "\n";
   exit;
}

?>